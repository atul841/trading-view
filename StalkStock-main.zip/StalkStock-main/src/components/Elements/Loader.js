import React from "react";

const Loader = () => {
  return (
    <ul className="loader">
      <li />
      <li />
      <li />
    </ul>
  );
};

export default Loader;
